package googlemaps.example.com.estudianteapp;

import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;

public class localizador extends ListActivity {


    private Context context;
    private static String url="http://carbono.utpl.edu.ec:8080/smartlandiotv2/webresources/entidades.datos/get?apikey=4816ac48c9bf57cb37d329da55d6010";

   // private static final String ID="Id";
    private static final String HORA="Hora";
    private static final String TEMPERATURA="Temperatura";
    private static final String FECHA="Fecha";

    ArrayList<HashMap<String, String>> jsonlist=new ArrayList<HashMap<String,String>>();
    ListView lv;

    String dato;
    Intent intent;
    Bundle extras;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.obtenerjson);
        new ProgressTask(localizador.this).execute();

    }

    private class ProgressTask extends AsyncTask<String, Void, Boolean> {
        private ProgressDialog dialog;
        private ListActivity activity;
        private Context context;
        public ProgressTask(ListActivity activity){
            this.activity=activity;
            context=activity;
            dialog=new ProgressDialog(context);
        }
        @Override
        protected void onPreExecute() {
            this.dialog.setMessage("Obteniendo Datos..");
            this.dialog.show();
        }
        @Override
        protected void onPostExecute(Boolean result) {
            if(dialog.isShowing()){
                dialog.dismiss();
            }
            ListAdapter adapter=new SimpleAdapter(context, jsonlist, R.layout.json, new String[] {FECHA,HORA,TEMPERATURA}, new int[]{R.id.fecha,R.id.hora,R.id.temp});
            setListAdapter(adapter);
            lv=getListView();

        }
        @Override
        protected Boolean doInBackground(String... params) {
            JSONParser jParser=new JSONParser();
            JSONArray json=jParser.getJSONFromUrl(url);
            for(int i=0; i<json.length();i++){
                try {
                    JSONObject c=json.getJSONObject(i);
                   // String vId=c.getString("id");
                    String vFecha=c.getString("fecha");
                    String vTemp=c.getString("temperatura");
                    String vHora=c.getString("hora");


                    HashMap<String, String> map= new HashMap<String, String>();
                    //para hacer la busqueda tan solo agregue el if y Para presentar todas las filas se quita el if
                    //Ademas creo el intent con bundle para traer los datos q se envian en la activity buscador
                    Intent intent=getIntent();
                    Bundle bundle=intent.getExtras();
                    String dato;
                    dato=bundle.getString("Dato");
                    if(bundle!=null) {
                        if (vFecha.equals(dato)) {
                            //map.put(ID, vId);
                            map.put(HORA, vHora);
                            map.put(TEMPERATURA, vTemp);
                            map.put(FECHA, vFecha);
                            jsonlist.add(map);
                        }//fin if
                    }
                } catch (JSONException e) {
                    // TODO: handle exception
                    e.printStackTrace();
                }
            }
            return false;
        }


    }
}
